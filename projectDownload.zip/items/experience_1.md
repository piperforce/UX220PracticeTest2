<h3>Charity Fundraiser</h3>

In August 2020, after 16 years, we had our last charity fundraiser for childrens wish Foundation.it was centimental to me as it was the last fundraiser we had before my uncle, who ran the fundraiser, passed away from stage 4 esophagul cancer later in October of the same year. My favourite memory from the event was having Strodes BBQ cook ofr us and getting a photos of my uncle with what would be the last roast hed experience. I'd give this experience an A.

<h3> Working at staples</h3>

In July 2019, I got my first job. I worked at Staples for the next 4 years and the experience was fun. I stocked shelves, helped on cash, helped customers, and built awesome relationships with both customers and my coworkers. However, in the 4 years I had 4 seperate managers due to multiple reasons. Some of these managers were better than others. I'd give this experience a C. 


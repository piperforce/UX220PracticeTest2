<h3> Getting my blackbelt</h3>

In July of 2019, I became a black belt. I trained for 9 years prior to receiving my blackbelt and the hard work made it even more worth it. I really enjoyed the friends and family that came to celebrate my acheivement with me even though I usually hate being the centre of attention. This was defintely an A+ Experience for me 